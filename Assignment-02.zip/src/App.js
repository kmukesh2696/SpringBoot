
import './App.css';

import AllIssuesPage from "./AllIssuesPage.js";
function App() {
  return (
    <div >
     <AllIssuesPage/>
    </div>
  );
}

export default App;

export default 

{
  comments:
          [
            {
              "id":1,
               "IssueDescription":"On Clicking Delete.the appliction crashes",
                "sevrity":"Critical",
                 "Status":"Open"
              },
              {
              "id":2,
               "IssueDescription":"The Heading Add is Worngly displayed as Edit",
                "sevrity":"Minor",
                 "Status":"Closed"
              },
              {
              "id":3,
               "IssueDescription":"The payment functionlity is missing",
                "sevrity":"Major",
                 "Status":"In Progress"
              }
          ]
        };
      
  